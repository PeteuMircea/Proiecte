import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32

class IntSquareClient(Node):
    def __init__(self):
        super().__init__('int_square_client')
        self.publisher_ = self.create_publisher(Int32, 'square_number', 10)
        self.subscription = self.create_subscription(
            Int32,
            'square_number_response',
            self.listener_callback,
            10)
        self.subscription  # previne o erroare
        self.result = None

    def listener_callback(self, msg):
        self.result = msg.data
        self.get_logger().info(f"Raspuns Servis= {self.result}")

    def send_request(self, number):
        msg = Int32()
        msg.data = number
        self.get_logger().info(f"Nr. trimis= {number}")
        self.publisher_.publish(msg)
        while self.result is None:
            rclpy.spin_once(self)
        return self.result

def main(args=None):
    rclpy.init(args=args)
    node = IntSquareClient()

    while True:
        try:
            number = int(input("Enter a nr. = "))
            response = node.send_request(number)
            print(f"Nr. original este {number} si patratul acestuia e {response}")
        except ValueError:
            print("Error")
        except KeyboardInterrupt:
            print("\nExiting...")
            break
    
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
