import rclpy
from rclpy.node import Node #din ros se importa Node
from std_msgs.msg import Int32 

class IntSquareServer(Node):
    def __init__(self):
        super().__init__('int_square_server')
        self.subscription = self.create_subscription(
            Int32,
            'square_number',
            self.callback,
            10)
        self.publisher_ = self.create_publisher(Int32, 'square_number_response', 10)

    def callback(self, msg):
        number = msg.data
        square = number * number
        self.get_logger().info(f"Nr. : {number}, sending back: {square}")
        response = Int32()
        response.data = square
        self.publisher_.publish(response)

def main(args=None):
    rclpy.init(args=args)
    node = IntSquareServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
