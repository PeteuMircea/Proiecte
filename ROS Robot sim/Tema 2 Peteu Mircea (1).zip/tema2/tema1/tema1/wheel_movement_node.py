import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import math
import threading
import time

class WheelMovementNode(Node):
    def __init__(self):
        super().__init__('wheel_movement_node')

        self.joint_pub = self.create_publisher(JointState, '/joint_states', 10)

        # Variables for animation
        self.current_angle = 0.0
        self.target_angle = 0.0
        self.animation_speed = 0.1  # Radians per tick

        # Run the publisher loop at 30Hz for smooth animation
        self.timer = self.create_timer(0.033, self.update_and_publish)

        self.get_logger().info("Wheel node ready.")
        self.get_logger().info("[Exemple: (Correct:5); (Incorrect:5m)]")
        self.get_logger().info("Type a distance and hit Enter:")

        # Input thread
        self.input_thread = threading.Thread(target=self.input_loop)
        self.input_thread.daemon = True #tl;dr: the daemon is used to promptly retrive node and topic information. <-from github:
        #https://github.com/clearpathrobotics/roscon2024-workshop-demystifying-ros2-networking/blob/main/exercises/2_daemon.md
        self.input_thread.start()

    def input_loop(self):
        while rclpy.ok():
            try:
                user_input = input("Target Distance: ")
                distance = float(user_input)
                
                # Calculate the target angle
                wheel_circumference = 1.0 #perimetru rotilor
                total_rotation = (distance / wheel_circumference) * 2 * math.pi
                
                self.target_angle = total_rotation # *180/pi pt deg
                self.get_logger().info(f"Moving to angle: {self.target_angle:.2f} rad")
                
            except ValueError:
                print("Incorrect.")

    def update_and_publish(self):
        # -- Animation Logic --
        # Slowly move current_angle towards target_angle
        if abs(self.current_angle - self.target_angle) > 0.01: #abs = Returns the absolute value of a number. Ex: |-3| = 3
            if self.current_angle < self.target_angle:         # Ex: |0 (original) - n|=m; m<n (unghi dorit)=> misca inainte
                self.current_angle += self.animation_speed     #                           m<n (unghi dorit)=> misca inapoi
            else:
                self.current_angle -= self.animation_speed
        else:
            # Snap to exact value if very close
            self.current_angle = self.target_angle

        # -- Publish --
        # Create a new JointState message object
        msg = JointState()
        
        # Add a timestamp. This is CRITICAL for RViz/TF. 
        # It tells the system "this is where the joints are AT THIS MOMENT."
        msg.header.stamp = self.get_clock().now().to_msg()
        
        # List the names of the joints exactly as they appear in your URDF.
        msg.name = [
            'base_front_left_wheel',
            'base_front_right_wheel',
            'base_back_left_wheel',
            'base_back_right_wheel'
        ]
        
        # Assign the current rotation (in radians) to each joint.
        msg.position = [
            self.current_angle, 
            self.current_angle, 
            self.current_angle, 
            self.current_angle
        ]
        
        # Send the message to the /joint_states topic.
        # Robot_state_publisher hears this and updates the 3D model.
        self.joint_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = WheelMovementNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()