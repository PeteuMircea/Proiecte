import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    urdf_file = os.path.join(
        os.getenv('HOME'), 'Desktop', 'robot_T2.urdf'
    )

    with open(urdf_file, 'r') as f:
        robot_description = f.read()

    rviz_config = os.path.join(
        os.getenv('HOME'), 'ros2_ws', 'src', 'tema1', 'robot.rviz'
    )

    return LaunchDescription([
        # 1. Publishes the robot structure (URDF) to TF
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_description}],
        ),

        # 2. Opens RViz
        Node(
            package='rviz2',
            executable='rviz2',
            arguments=['-d', rviz_config],
            output='screen',
        ),
        
    ])