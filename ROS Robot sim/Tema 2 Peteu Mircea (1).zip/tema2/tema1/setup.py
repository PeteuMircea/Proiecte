from setuptools import find_packages, setup

package_name = 'tema1'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['robot.launch.py']),
        ('share/' + package_name + '/rviz', ['robot.rviz']),
    ],

    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='thor',
    maintainer_email='thor@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': ['intsqare = tema1.intsqare:main',  
                            'client = tema1.client:main',
                            'wheel_movement = tema1.wheel_movement_node:main',
        ],
    },
)
